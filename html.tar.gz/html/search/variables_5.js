var searchData=
[
  ['score',['score',['../class_player.html#a38a6dafe988a768a435cc0a9fde38e46',1,'Player']]]
];
