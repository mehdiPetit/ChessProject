var searchData=
[
  ['piece',['piece',['../class_case.html#aecf7c05bfb4eaf8332f9c556319993a3',1,'Case']]],
  ['pieces',['pieces',['../class_player.html#aae72d6ce61d41bee8d04318baa36b239',1,'Player']]],
  ['player_5f1',['player_1',['../class_game.html#a093479c41ed1861885680ced9338b25e',1,'Game']]],
  ['player_5f2',['player_2',['../class_game.html#a2146316babdcda94567af75f94b73106',1,'Game']]]
];
