var searchData=
[
  ['score',['score',['../class_player.html#a38a6dafe988a768a435cc0a9fde38e46',1,'Player']]],
  ['setboard',['setBoard',['../class_game.html#a972198b713c8d23acf06c0e95cc1c872',1,'Game']]],
  ['setcoordinate',['setCoordinate',['../class_piece.html#aadf96b2e3cdf28dcc52f670f8bc4e0f5',1,'Piece']]],
  ['setpiece',['setPiece',['../class_case.html#aaa0ce6e0cfcb0fc6bf38c7be1a82b1e0',1,'Case']]],
  ['setpieces',['setPieces',['../class_player.html#a31d381a29c010c26d69a4cfd30c37049',1,'Player']]],
  ['setscore',['setScore',['../class_player.html#ae02f0030bc93cd08c014dd48943c0304',1,'Player']]],
  ['setvalue',['setValue',['../class_piece.html#a889ea7d9eb4b691a07143e9084382b2a',1,'Piece']]],
  ['setx',['setX',['../class_coordinate.html#a330c37af7bb87f30a55173617112eade',1,'Coordinate']]],
  ['sety',['setY',['../class_coordinate.html#ad4b804672ac33f50024d66f3bb46e033',1,'Coordinate']]],
  ['switchpiece',['switchPiece',['../class_case.html#a3a1a33aeb2401ff0f08dfb89b63832fa',1,'Case']]]
];
