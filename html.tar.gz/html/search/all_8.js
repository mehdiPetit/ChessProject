var searchData=
[
  ['queen',['Queen',['../class_queen.html',1,'Queen'],['../class_queen.html#ab0d98820ff74906af19e0b7495348f8b',1,'Queen::Queen()']]],
  ['queen_2ecpp',['Queen.cpp',['../_queen_8cpp.html',1,'']]],
  ['queen_2eh',['Queen.h',['../_queen_8h.html',1,'']]]
];
