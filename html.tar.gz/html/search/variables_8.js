var searchData=
[
  ['y',['y',['../class_coordinate.html#a13eedbab9e112ef9f8685c12f1aed009',1,'Coordinate']]]
];
