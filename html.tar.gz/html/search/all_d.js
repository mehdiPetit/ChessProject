var searchData=
[
  ['x',['x',['../class_coordinate.html#aed3fecfb15ebabe5b4905820c1999b0b',1,'Coordinate']]]
];
