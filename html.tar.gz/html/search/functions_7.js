var searchData=
[
  ['pawn',['Pawn',['../class_pawn.html#a28054ee4fa72e69892be4d250191aa22',1,'Pawn']]],
  ['piece',['Piece',['../class_piece.html#afc89acd5b05abd2f8fa4f60ee7ca3b20',1,'Piece::Piece(unsigned int var_temp)'],['../class_piece.html#af1ce807c73a4b82abf28161ea07a95a2',1,'Piece::Piece(unsigned int var_temp, Coordinate coordinate)']]],
  ['play',['play',['../class_game.html#a42caf1acd21c76c606796caa7309c81a',1,'Game']]],
  ['player',['Player',['../class_player.html#affe0cc3cb714f6deb4e62f0c0d3f1fd8',1,'Player::Player()'],['../class_player.html#a355464bd2331faa49dfcc259174ac0ee',1,'Player::Player(std::string color_temp)']]],
  ['print',['print',['../class_board.html#a93825eef8ed4d502861a855ae0610e21',1,'Board']]]
];
