var searchData=
[
  ['initattributes',['initAttributes',['../class_case.html#a975dfe51150f130269224046566ee774',1,'Case::initAttributes()'],['../class_player.html#acd7645a07397ed3d4a499b139784eeb3',1,'Player::initAttributes()']]],
  ['ispieceowner',['isPieceOwner',['../class_player.html#acd154fbc75679e8bd21ae790836c8623',1,'Player']]],
  ['isplayerchessed',['isPlayerChessed',['../class_player.html#ab792f06e8da9ce878b2de013fb04b103',1,'Player']]]
];
