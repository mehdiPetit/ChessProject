var searchData=
[
  ['value',['value',['../class_piece.html#a8933ca826f6c9b958f781eaa0160c2b7',1,'Piece']]]
];
