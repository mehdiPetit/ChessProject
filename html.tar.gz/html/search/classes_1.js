var searchData=
[
  ['case',['Case',['../class_case.html',1,'']]],
  ['coordinate',['Coordinate',['../class_coordinate.html',1,'']]]
];
