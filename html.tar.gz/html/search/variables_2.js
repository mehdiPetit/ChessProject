var searchData=
[
  ['isfirstmoove',['isFirstMoove',['../class_pawn.html#abf900800320dfe79093b50baeda255d4',1,'Pawn']]]
];
