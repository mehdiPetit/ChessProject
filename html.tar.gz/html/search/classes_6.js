var searchData=
[
  ['queen',['Queen',['../class_queen.html',1,'']]]
];
