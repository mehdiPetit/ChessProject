var searchData=
[
  ['board',['board',['../class_board.html#a4d7ad04642783accc669fccfae9a9727',1,'Board::board()'],['../class_game.html#ae38e501e177586af48d2e2300b6be4ba',1,'Game::board()']]]
];
