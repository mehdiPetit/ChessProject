var searchData=
[
  ['color',['color',['../class_player.html#ac2e6856437961bb592e38ecb40c2f348',1,'Player']]],
  ['coordinate',['coordinate',['../class_piece.html#a9e92373c8fffc1f5efb20d62204b70cf',1,'Piece']]]
];
