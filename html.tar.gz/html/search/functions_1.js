var searchData=
[
  ['case',['Case',['../class_case.html#a14237e17aab1829965adab76b747db6c',1,'Case']]],
  ['coordinate',['Coordinate',['../class_coordinate.html#aac6f323a685fc1e88fbea9c86f1e600d',1,'Coordinate::Coordinate()'],['../class_coordinate.html#a8851ee18948f8b6433b0afc6b59095a7',1,'Coordinate::Coordinate(unsigned int t_x, unsigned int t_y)']]]
];
