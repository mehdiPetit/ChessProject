var searchData=
[
  ['king',['King',['../class_king.html#a61f66f3da9c9b8cda2541fb3e1be8743',1,'King']]],
  ['knight',['Knight',['../class_knight.html#ada9451f9c4ae0b30e7c0f0eaa7c78aac',1,'Knight']]]
];
