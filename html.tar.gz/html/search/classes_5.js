var searchData=
[
  ['pawn',['Pawn',['../class_pawn.html',1,'']]],
  ['piece',['Piece',['../class_piece.html',1,'']]],
  ['player',['Player',['../class_player.html',1,'']]]
];
