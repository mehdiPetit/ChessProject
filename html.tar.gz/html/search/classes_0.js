var searchData=
[
  ['bishop',['Bishop',['../class_bishop.html',1,'']]],
  ['board',['Board',['../class_board.html',1,'']]]
];
