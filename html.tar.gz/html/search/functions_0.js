var searchData=
[
  ['bishop',['Bishop',['../class_bishop.html#abc54c861677423ac25f0c819cb9cbb55',1,'Bishop']]],
  ['board',['Board',['../class_board.html#a9ee491d4fea680cf69b033374a9fdfcb',1,'Board']]]
];
